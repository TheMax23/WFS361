import React from 'react';
import './NavButton.css';


const NavigationButtons = ({ onPrevious, onNext, pageNumber }) => {
  return (
    <div className="nav-buttons-container">
      <button className="nav-btn" onClick={onPrevious}>
       Previous Page
      </button>
      <span className="page-number">{pageNumber}</span>
      <button className="nav-btn" onClick={onNext}>
        Next Page
      </button>
    </div>
  );
};

export default NavigationButtons;
