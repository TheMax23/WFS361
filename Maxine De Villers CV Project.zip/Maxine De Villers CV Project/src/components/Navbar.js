import React from 'react';
import './Navbar.css';


const Navbar = ({ currentSection, onNavigate }) => {
  const navItems = ['Intro', 'Skills', 'Education', 'Experience'];

  return (
    <nav className="navbar">
      {navItems.map((item) => (
        <button
          key={item}
          className={`nav-button ${currentSection === item ? 'active' : ''}`}
          onClick={() => onNavigate(item)}
        >
          {item}
        </button>
      ))}
    </nav>
  );
};

export default Navbar;
