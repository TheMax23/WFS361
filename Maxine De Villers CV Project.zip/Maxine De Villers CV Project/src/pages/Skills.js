import React from 'react';
import '../styles/Skills.css';
import gearIcon from '../assets/gear_wheel.png';

function Skills() {
  return (
    <div className="skills-page">
      <img src={gearIcon} alt="Skills icon" className="skills-image" />
      <div className="skills-content">
        <h2>Skills</h2>
        <p className="subtitle">Let me tell you a bit about my skills</p>
        <p>
        I find myself to be an outgoing person and good when it comes to working in a team. 
        I am someone who is computer literate, have excellent time management skills and the ability to adapt well while handling pressure efficiently. 
        I believe I have good communication skills and great attention to detail. 
        I am more than willing to learn new things. 
        I present a set of leadership skills, good decision making and patience in a variety of settings
        </p>
      </div>
    </div>
  );
}

export default Skills;

