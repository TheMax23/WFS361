import React from 'react';
import '../styles/Intro.css'; 
import profilePic from '../assets/profile_picture.jpg';

const Intro = () => {
  return (
    <div className="intro-page">
      <h2>Maxine Elizabeth De Villiers</h2>
      <p className="subtitle">CV</p>

      <div className="cards-container">
        <div className="card">
          <img src={profilePic} alt="Profile" width/>
          <h3>Let me tell you who I am</h3>
          <p>
            My name is Maxine Elizabeth De Villiers, and I am current a student at Belgium Campus ITversity.
            I am studying towards at Diploma in Information Technology, specializing in Software Development.
          </p>
        </div>

        <div className="card">
          <img src={require('../assets/contact.png')} alt="Contact" />
          <h3>Contact details</h3>
          <p>
            Phone Number: 076 206 4032
          </p>
          <p>
            Email: maxidv017@gmail.com
          </p>
        </div>

        <div className="card">
          <img src={require('../assets/links.jpeg')} alt="Links" />
          <h3>Profile Links</h3>
          <p>
            LinkedIn: <a href="https://www.linkedin.com/in/maxine-de-villiers-778b481b4/" target="_blank" rel="noopener noreferrer">Maxine De Villiers LinkedIn Profile</a>
          </p>
          <p>
            GitHub: <a href="https://github.com/TheMax23" target="_blank" rel="noopener noreferrer">TheMax23 GitHub Profile</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Intro;
