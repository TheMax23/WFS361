import React from 'react';
import '../styles/Experience.css';
import experienceIcon from '../assets/computer.jpg';

function Experience() {
  return (
    <div className="experience-page">
      <img src={experienceIcon} alt="Experience icon" className="experience-image" />
      <div className="experience-content">
        <h2>Experience</h2>
        <p className="subtitle">Experience gained through education</p>
        <p>
        I have a broad range of experience  across various areas of technology and business. 
        My technical background includes web development using modern tools and languages such as JavaScript, HTML, CSS, Python, C# Java and React.js.
        I have also worked on network development, software analysis, design and testing. 
        I have done project, business and database management. I have experience in maths as well as statics. 
        I have done enterprise systems and innovation and leadership.
        </p>
      </div>
    </div>
  );
}

export default Experience;



