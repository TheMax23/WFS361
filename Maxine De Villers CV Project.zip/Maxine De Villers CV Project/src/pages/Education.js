import React from 'react';
import '../styles/Education.css';
import educationIcon from '../assets/education.png'; // Update with your actual icon path

function Education() {
  return (
    <div className="education-page">
      <img src={educationIcon} alt="Education icon" className="education-image" />
      <div className="education-content">
        <h2>Education</h2>
        <p className="subtitle">Insight to my educatonal background</p>
        <p>
        I had received an education at Edenglen high school. Then my college education consists studying a diploma in IT at Belgium Campus ITveristy with a specialization in software development.
        </p>
        <p>
        In high school I had taken computer applications technology and had always enjoyed working with computers. 
        I had decided to follow an IT studying path going into the specialization of software development. 
        The streams I have chosen is programming and web development. Apart of my college education, some business subjects were also implemented for the best possible outcomes when dealing with both aspects of a company and it's IT system.
        </p>
      </div>
    </div>
  );
}

export default Education;



