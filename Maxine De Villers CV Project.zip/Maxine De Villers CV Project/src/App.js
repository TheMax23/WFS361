import React, { useState } from 'react';
import Navbar from './components/Navbar';
import NavigationButtons from './components/NavButtons';
import Intro from './pages/Intro';
import Skills from './pages/Skills';
import Education from './pages/Education';
import Experience from './pages/Experience';

function App() {
  const sections = ['Intro', 'Skills', 'Education', 'Experience'];
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);

  const handleNavigate = (section) => {
    const index = sections.indexOf(section);
    if (index !== -1) setCurrentSectionIndex(index);
  };

  const handlePrevious = () => {
    setCurrentSectionIndex((prev) => Math.max(0, prev - 1));
  };

  const handleNext = () => {
    setCurrentSectionIndex((prev) => Math.min(sections.length - 1, prev + 1));
  };

  const renderContent = () => {
    switch (sections[currentSectionIndex]) {
      case 'Intro':
        return <Intro />;
      case 'Skills':
        return <Skills />;
      case 'Education':
        return <Education />;
      case 'Experience':
        return <Experience />;
      default:
        return null;
    }
  };

  return (
    <div>
      <Navbar
        currentSection={sections[currentSectionIndex]}
        onNavigate={handleNavigate}
      />
      {renderContent()}
      <NavigationButtons
        onPrevious={handlePrevious}
        onNext={handleNext}
        pageNumber={currentSectionIndex + 1}
      />
    </div>
  );
}

export default App;


