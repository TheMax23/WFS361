import React from "react";
import "./index.css";
import imageSrc from "./snowymountains.jpeg";

function PostCard() {
  return (
    <div className="card">
      <img src={imageSrc} alt="snowy mountains imagery" className="image" />
      <div className="content">
        <p className="date">4 days ago</p>
        <p className="title">Post One</p>
        <p className="description">
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Error eaque
          temporibus atque facilis, commodi voluptas quisquam ab tenetur
          obcaecati nisi.
        </p>
      </div>
      <div className="footer">
        <div className="footer-item">
          <p className="footer-value">
            4 <sup>m</sup>
          </p>
          <p className="footer-label">READ</p>
        </div>
        <div className="footer-item">
          <p className="footer-value">5132</p>
          <p className="footer-label">VIEWS</p>
        </div>
        <div className="footer-item">
          <p className="footer-value">4</p>
          <p className="footer-label">COMMENTS</p>
        </div>
      </div>
    </div>
  );
}

function PostGrid() {
  return (
    <div className="main-container">
      <PostCard />
      <PostCard />
      <PostCard />
      <PostCard />
    </div>
  );
}

export default PostGrid;

