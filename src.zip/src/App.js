import "./App.css";
import PostCard from "./PostCard";

function App() {
  return (
    <div style={{ padding: "45px", display: "flex", justifyContent: "center" }}>
      <PostCard />
    </div>
  );
}

export default App;
