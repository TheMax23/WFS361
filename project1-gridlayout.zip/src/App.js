import React from "react";
import "./App.css";

export default function App() {
  return (
    <div className="grid-container">
      <div className="header"></div>
      <div className="main"></div>
      <div className="top-right"></div>
      <div className="top-right-2"></div>
      <div className="bottom-right"></div>
      <div className="bottom-right-2"></div>
      <div className="footer"></div>
    </div>
  );
}
