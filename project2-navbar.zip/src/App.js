import React from 'react';
import './App.css';

function Navbar() {
  const navItems =[
    {name: "Home", isActive: true},
    {name: "Products", href: '#'},
    {name: "Services", href: '#'},
    {name: "Team", href: '#'},
    {name: "Portfolio", href: '#'},
    {name: "Blog", href: '#'},
    {name: "Contact", href: '#'},
    {name: "Go to my blog", className: "blog-link"}
  ];

  return (
    <nav className ="navbar">
      <ul className = "nav-links">
        {navItems.map((item, index) =>(
          <li key={index}>
            <a
              href={item.href}
              className={item.isActive ? "active" : item.className}
            >
              {item.name}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  )
}

function App() {
  return (
    <div className="App">
      <Navbar />
    </div>
  );
}

export default Navbar;